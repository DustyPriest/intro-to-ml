# Assignment 3: Job Salary Prediction
## Accompanying python code

Student Name: `Hugo Akindele-Obe`

Student ID: `1444970`

## Research Question: Does Unlabelled data improve Job salary prediction?

__*Please check the included JupyterNotebook for explanations accompanying the code sections.*__
